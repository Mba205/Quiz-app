function addQuestion() {
    const container = document.getElementById('questions-container');
    const newQuestionBlock = `
        <div class="question-block">
            <input type="text" name="question" placeholder="Enter question" required>
            <input type="text" name="option_a" placeholder="Option A" required>
            <input type="text" name="option_b" placeholder="Option B" required>
            <input type="text" name="option_c" placeholder="Option C" required>
            <input type="text" name="option_d" placeholder="Option D" required>
            <input type="text" name="correct_answer" placeholder="Correct answer (a, b, c, d)" required>
        </div>`;
    container.insertAdjacentHTML('beforeend', newQuestionBlock);
}

document.getElementById('set-quiz-form').onsubmit = function(event) {
    event.preventDefault();
    const questions = Array.from(document.querySelectorAll('.question-block')).map(block => {
        return {
            question: block.querySelector('input[name="question"]').value,
            option_a: block.querySelector('input[name="option_a"]').value,
            option_b: block.querySelector('input[name="option_b"]').value,
            option_c: block.querySelector('input[name="option_c"]').value,
            option_d: block.querySelector('input[name="option_d"]').value,
            correct_answer: block.querySelector('input[name="correct_answer"]').value
        };
    });
    const timer = document.getElementById('timer').value;
    localStorage.setItem('quizQuestions', JSON.stringify(questions));
    localStorage.setItem('quizTimer', timer);
    alert('Quiz saved successfully!');
};

function showStudentSection() {
    document.getElementById('teacher-section').style.display = 'none';
    document.getElementById('student-section').style.display = 'block';
}

document.getElementById('student-form').onsubmit = function(event) {
    event.preventDefault();
    const studentName = document.getElementById('student-name').value;
    const studentIndex = document.getElementById('student-index').value;
    if (studentName && studentIndex) {
        localStorage.setItem('studentName', studentName);
        localStorage.setItem('studentIndex', studentIndex);
        document.getElementById('student-form').style.display = 'none';
        startQuiz();
    }
};

function startQuiz() {
    const quizContainer = document.getElementById('quiz-container');
    const quizForm = document.getElementById('quiz-form');
    const questions = JSON.parse(localStorage.getItem('quizQuestions'));
    const timerValue = parseInt(localStorage.getItem('quizTimer'));

    questions.forEach((question, index) => {
        const questionBlock = `
            <div class="question-block">
                <div class="question">${question.question}</div>
                <div class="answers">
                    <label><input type="radio" name="question${index}" value="a" required> ${question.option_a}</label>
                    <label><input type="radio" name="question${index}" value="b" required> ${question.option_b}</label>
                    <label><input type="radio" name="question${index}" value="c" required> ${question.option_c}</label>
                    <label><input type="radio" name="question${index}" value="d" required> ${question.option_d}</label>
                </div>
            </div>`;
        quizForm.insertAdjacentHTML('beforeend', questionBlock);
    });

    quizContainer.style.display = 'block';
    startTimer(timerValue);
}

function startTimer(duration) {
    let timeLeft = duration;
    const timerDisplay = document.getElementById('time');
    timerDisplay.textContent = timeLeft;

    const timerInterval = setInterval(() => {
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            submitQuiz();
        } else {
            timerDisplay.textContent = timeLeft;
            timeLeft -= 1;
        }
    }, 1000);

    document.getElementById('quiz-form').onsubmit = function(event) {
        event.preventDefault();
        clearInterval(timerInterval);
        submitQuiz();
    };
}

function submitQuiz() {
    const answers = new FormData(document.getElementById('quiz-form'));
    const correctAnswers = JSON.parse(localStorage.getItem('quizQuestions')).map(q => q.correct_answer);
    let score = 0;
    for (let [question, answer] of answers.entries()) {
        const questionIndex = parseInt(question.replace('question', ''));
        if (correctAnswers[questionIndex] === answer) {
            score++;
        }
    }

    const totalQuestions = correctAnswers.length;
    const percentageScore = (score / totalQuestions) * 100;
    document.getElementById('results').innerHTML = `Your score is: ${percentageScore.toFixed(2)}%`;

    // Store student's score in localStorage
    const studentName = localStorage.getItem('studentName');
    const studentIndex = localStorage.getItem('studentIndex');
    const scores = JSON.parse(localStorage.getItem('scores')) || [];
    scores.push({ name: studentName, index: studentIndex, score: percentageScore });
    localStorage.setItem('scores', JSON.stringify(scores));

    // Show teacher's section to view scores
    document.getElementById('teacher-section').style.display = 'block';

    // Update scores table
    updateScoresTable(scores);
}

function updateScoresTable(scores) {
    const tableBody = document.getElementById('scores-body');
    tableBody.innerHTML = '';

    scores.forEach(score => {
        const row = `<tr>
                        <td>${score.name}</td>
                        <td>${score.index}</td>
                        <td>${score.score.toFixed(2)}%</td>
                    </tr>`;
        tableBody.insertAdjacentHTML('beforeend', row);
    });

    // Show teacher's results section
    document.getElementById('teacher-results').style.display = 'block';
}
